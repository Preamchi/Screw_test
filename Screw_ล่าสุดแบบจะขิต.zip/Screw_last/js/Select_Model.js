function Model_Value() {
    $.ajax({
        url: "ajax/Model_value.php",
        async: false,
        cache: false,

        success: function(result) {
  /*           console.log(result); */
          var myJson = JSON.parse(result);
         
            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
            cartoptions += "<option value='0'>Please select a model before....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Model'];
                cartoptions += "<option value='" + name + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("model_loop").innerHTML = cartoptions;
             
        }
    });
}