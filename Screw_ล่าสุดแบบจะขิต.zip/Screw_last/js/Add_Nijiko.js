function Add_Nijiko() {
   
    var employee = document.getElementById('emp').value;
    var nijiko_name = document.getElementById('nijiko_input').value;   
    var station = document.getElementById('station_loop2').value;
    var screw = document.getElementById('screw_loop').value;

    if ((!nijiko_name) || (!station)|| (!screw)){
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {

        $.ajax({
            type: "GET",
            url: "ajax/Nijiko_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: employee,
                Nijiko_Name: nijiko_name,
                Station : station,
                Screw : screw,
                

            
            },
            success: function(result) {
                if(result == 'have_data'){ 
                 
                    Swal.fire({
                    width: 400,
                    title: 'Add failed!',
                    text: 'information already exists.',
                    icon: 'error',
                    showConfirmButton: false,
                    timer: 1500
                  });
                  document.getElementById("nijiko_input").value = '';
                  document.getElementById("station_loop2").value = '';
                  document.getElementById("screw_loop").value = '';
              
                }else{
                    Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });

           $('#AddNijikoModal').modal('hide');
           $('.modal-backdrop').remove();
           $("#addnijiko").trigger("reset");
           Load_Nijiko();
                }
           
     }
        });
    }
}
