
function Send_ID(e) {
    
    document.getElementById("station_id").value = e;
    var st_id = e;

    $.ajax({
        type: "GET",
        url: "ajax/Station_Editmodal.php",
        async: false,
        cache: false,
        data: {
            ST_ID : st_id
        },

        success: function(result) {
       
            const myJson = JSON.parse(result);
            document.getElementById("station_data").value = myJson.Station;


   
        }
    });

   
}
function Update_Station() {
    var emp = document.getElementById('emp').value;
    var st_id = document.getElementById("station_id").value; 
    var new_station = document.getElementById("station_data").value;



if ((!new_station)) {
    Swal.fire({
        width: 400,
        title: 'Please input informaion!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 1500
      });
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Station_Update.php",
        async: false,
        cache: false,
        data: {
          Emp : emp,
          ST_ID : st_id,
          New_Station : new_station

        },
    success: function(result){
        if (result == 'have_data'){
            Swal.fire({
                width: 400,
                title: 'Add failed!',
                text: 'User information already exists.',
                icon: 'error',
                showConfirmButton: false,
                timer: 1700
              });
              document.getElementById("stname_input").value = '';
        }else{
        Swal.fire({
            width: 400,
            title: 'Update Successfully!',
            icon: 'success',
            showConfirmButton: false,
            timer: 1500
          });
        //modal close
        $('#EditStationModal').modal('hide');
        $('.modal-backdrop').remove(); 
        Load_Station(); 
        }
    }  
});
}
}