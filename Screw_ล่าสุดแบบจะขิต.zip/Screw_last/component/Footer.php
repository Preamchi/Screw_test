<!-- <footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">
                <li class="nav-item">
                </li>
            </ul>
        </nav>
        <div class="copyright m-auto">
            2023, made website by <b>MFD System of STTC</b>
            <img width="100" height="25" src="img/sonyinternal.png">
        </div>
    </div>
</footer>
 -->

<style>
.footer {

    background-color: #a09d9d;
    height: 2rem;
}
</style>



<footer class="footer fixed-bottom bg-dark  d-flex  justify-content-end align-items-center">
    <div class="container-fluid  d-flex  justify-content-end "><span class="text-muted ">© 2023, made website by <b>MFD
                System of STTC</b> <img width="100" height="25" src="img/sonyinternal.png"></span></div>
</footer>