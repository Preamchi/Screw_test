<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


/* $sql = " 
SELECT  [ID],[Channel] FROM [STT_DB].[IM].[SCREW_TQ_Channel] "; */

$Model = $_GET[Model_name]; 
$ST_ID = $_GET[Station_id]; 
$Line_ID = $_GET[Line]; 


$sql ="
SELECT 
 A.[ID] AS ID
,[Channel] AS CH
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B 
ON A.Model_Id = B.ID
WHERE A.Station_Id = '$ST_ID' AND B.Model = '$Model' AND B.Line_Id = '$Line_ID'";

/* SELECT 
 A.[ID] AS ID
,[Channel] AS CH
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B 
ON A.Model_Id = B.ID
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] C
ON B.Station_Id = C.ID WHERE C.ID = '$ST_ID' AND B.Model = '$Model' */

/* $sql ="
SELECT [ID] 
,[Channel] AS CH
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B 
ON A.Model_Id = B.ID
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] C
ON B.Station_Id = C.ID WHERE C. = '$ST_ID' AND B.Model = '$Model'"; */

$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata)


?>