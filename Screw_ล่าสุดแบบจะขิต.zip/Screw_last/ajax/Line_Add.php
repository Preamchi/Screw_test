<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Line_Name = $_GET[Line_name];

$sql_check = "
SELECT [Line] FROM [STT_DB].[IM].[SCREW_TQ_Line] WHERE Line = '$Line_Name'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){
    
   $sql="
   INSERT INTO [STT_DB].[IM].[SCREW_TQ_Line]
              ([Line]
              ,[Create_Date]
              ,[Create_By]
              ,[Update_Date]
              ,[Update_By])
       VALUES('".$Line_Name."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 
       
    $myfunction->exec($sql);
    echo $sql;
        
       }else{
           echo 'have_data';
       }
       
 
?>