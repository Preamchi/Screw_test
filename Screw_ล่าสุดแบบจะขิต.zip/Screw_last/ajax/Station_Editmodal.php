<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$ST_ID = $_GET[ST_ID];


$sql = "
SELECT [ID]
      ,[Station]
  FROM [STT_DB].[IM].[SCREW_TQ_Station] Where ID = '$ST_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_station = $val;
}

$data_station1 = json_encode($data_station);
    echo $data_station1;
    die;
    
 
?>