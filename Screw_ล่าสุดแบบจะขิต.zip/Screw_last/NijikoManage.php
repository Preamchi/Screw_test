<?php
include "connect/COMMON.php";
include "ajax/Head.php";


?>


<link href="css/Allpage.css" rel="stylesheet" />




<body>
    <?php require 'component/Tab.php';?>
    <div class="layout">
        <div class="container" id="main">
            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; ">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">
                        <i class="fas fa-screwdriver"></i>
                        <label class="text">Nijiko Manage</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end; margin-right: 1rem;">
                        <button type="button" class="btn-add" data-backdrop="static" data-toggle="modal"
                            data-target="#AddNijikoModal" onclick="Screw_Value(),Station_Value()">
                            <i class="fas fa-plus-circle"></i>&nbsp; Add Data
                        </button>
                    </div>

                    <!-- nijiko_data table -->
                    <div id="show_nijiko" class="scroll"></div>

                </div>
            </div>
            <!------------------------------------ All Modal Nijiko Page ------------------------------------------>
            <!-- Modal Add -->
            <div class="modal fade" id="AddNijikoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"> <i class="fas fa-plus-circle"></i>&nbsp;Add
                                Nijiko</h5>
                        </div>
                        <div class="modal-body p-5">
                            <!-- employee_id of user log in -->
                            <input id="emp" value="<?php echo $emp; ?>" hidden />
                            <form id="addnijiko">
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm">Nijiko Name</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="nijiko_input">
                                </div>

                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text " style="width: 100px;"
                                            for="inputGroupSelect01">Station</label>
                                    </div>
                                    <select class="custom-select " id="station_loop2" onchange="(this.value)">
                                    </select>
                                </div>
                                <div class="input-group input-group-sm ">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text " style="width: 100px;"
                                            for="inputGroupSelect01">Screw Type</label>
                                    </div>
                                    <select class="custom-select " id="screw_loop" onchange="(this.value)">
                                    </select>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                onclick="Clear_Nijiko()">Cancel</button>
                            <button type="button" class="btn btn-success" onclick="Add_Nijiko()">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Edit -->
            <input id="nijiko_id" hidden />
            <div class="modal fade" id="EditNijikoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-pen"></i>&nbsp;Edit Nijiko
                            </h5>
                        </div>
                        <div class="modal-body p-5">
                            <form>
                                <label>Nijiko Name:&nbsp;</label><input type="text" id="nijiko_data"
                                    style="border:none; background:none; " disabled />
                                <!--  <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm">Nijiko Name</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="nijiko_data">
                                </div> -->
                                <input type="text" id="station_data" hidden /><input id="station_id" hidden />
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text " style="width: 100px;"
                                            for="inputGroupSelect01">Station</label>
                                    </div>
                                    <select class="custom-select " id="station" onchange="(this.value)">
                                    </select>
                                </div>

                                <input type="text" id="screw_data" hidden /><input id="screw_id" hidden />
                                <div class="input-group input-group-sm ">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text " style="width: 100px;"
                                            for="inputGroupSelect01">Screw Type</label>
                                    </div>
                                    <select class="custom-select " id="screw" onchange="(this.value)">
                                    </select>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-success" onclick="Update_Nijiko()">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php require 'component/Footer.php';?>

    <!--------------------------- Script Function And JS File ---------------------------------->
    <!-- Load data func. -->
    <script>
    $(document).ready(function() {
        Load_Nijiko();
    });
    </script>

    <script>
    function Load_Nijiko() {
        document.getElementById("show_nijiko").innerHTML = '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/Nijiko_Table.php",
                async: false,
                cache: false,

                success: function(result) {
                    document.getElementById("show_nijiko").innerHTML = result;
                }
            });
        }, 1000);
    }
    </script>

    <!-- Clear form add func. -->
    <script>
    function Clear_Nijiko() {
        $("#addnijiko").trigger("reset");
    }
    </script>

    <script src="js/Add_Nijiko.js"></script>
    <script src="js/Update_Nijiko.js"></script>
    <script src="js/Del_Nijiko.js"></script>
    <script src="js/Select_Line.js"></script>
    <script src="js/Select_Screw.js"></script>
    <script src="js/Select_Channel.js"></script>
    <script src="js/Select_Station2.js"></script>


</body>