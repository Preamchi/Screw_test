<?php
include "ajax/Head.php";
include "connect/COMMON.php";
?>

<link href="css/Profile.css" rel="stylesheet" />

<style>
* {
    padding: 0;
    margin: 0
}

/* BG:Sea */
body {
    background-image: url('img/background.jpg');
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>


<body>

    <!-- Menu Tab Left-->
    <?php require 'component/Tab.php';?>
    <!-- Card Profile -->
    <div class="container" id="main" style="margin-left:4rem;">
        <div class="card " style="wEmailidth: 30rem; height:25rem; margin-left:4rem;">
            <div class="card-body pt-0 pl-0">

                <!-- Head Topic -->
                <div class="topic">
                    <i class="fas fa-address-card"></i>
                    <span class="text">My Profile</span>
                </div>

                <!-- Employee_Id OF User Log In From Head.php -->
                <input id="employee_login" value="<?php echo $emp; ?>" hidden />

                <!-- Form Profile -->
                <form class="textbox ml-3 p-3 ">
                    <div class="form-group">
                        <span for="emp_id">Employee ID</span>
                        <input type="text" class="form-control" id="emp_id" disabled />
                    </div>
                    <div class="form-group">
                        <span for="emp_name">User Name</span>
                        <input type="text" class="form-control" id="emp_name" disabled />
                    </div>
                    <div class="form-group">
                        <span for="emp_role">Role</span>
                        <input type="text" class="form-control" id="emp_role" disabled />
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php require 'component/Footer.php';?>

    <!--------------------------- Script Function And JS File ---------------------------------->

    <!-- Load Data Func. -->
    <script>
    $(document).ready(function() {
        Profile();
    });
    </script>

    <script>
    function Profile() {
        var emp_login = document.getElementById("employee_login").value;

        $.ajax({
            url: "ajax/User_Profile.php",
            async: false,
            cache: false,
            data: {
                Emp_Login: emp_login
            },
            success: function(result) {

                const myJson = JSON.parse(result);
                document.getElementById("emp_id").value = myJson.Emp_ID;
                document.getElementById("emp_name").value = myJson.Emp_Name;
                document.getElementById("emp_role").value = myJson.Emp_Role;
            }
        });

    }
    </script>
</body>