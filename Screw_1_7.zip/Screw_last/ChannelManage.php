<?php
include "connect/COMMON.php";
include "ajax/Head.php";
?>

<link href="css/Allpage.css" rel="stylesheet" />

<body>
    <?php require 'component/Tab.php';?>
    <!------------------------------------ Channel Manage ------------------------------------------>
    <div class="layout">
        <div class="container" id="main">
            <div class="card "
                style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; padding-right: 14px; ">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">
                        <i class="fas fa-grip-horizontal"></i>
                        <label class="text">Channel Manage</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end; margin-right: 1.2rem;">
                        <button type="button" class="btn-add" data-backdrop="static" data-toggle="modal"
                            data-target="#AddChannelModal" onclick="Model_Value()">
                            <i class="fas fa-plus-circle"></i>&nbsp; Add Data
                        </button>
                    </div>
                    <!-- data table -->
                    <div id="show_channel"></div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade bd-example-modal-xl" id="AddChannelModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                    </div>
                    <div class="modal-body p-5">
                        <div class="row">
                            <div class="col-5 " style=" border-right: 2px solid #E9ECEF; ">
                                <input id="emp" value="<?php echo $emp; ?>" hidden />
                                <form id="addchannel">
                                    <div class="input-group input-group-sm mb-3">
                                        <div class="input-group-prepend">

                                            <label class="input-group-text " style="width: 90px;"
                                                for="inputGroupSelect01">Model</label>
                                        </div>
                                        <select class="custom-select " id="model_loop"
                                            onchange="Station_Where(this.value)">
                                        </select>
                                    </div>
                                    <div class="input-group input-group-sm mb-3">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text " style="width: 90px;">Station</label>
                                        </div>
                                        <select class="custom-select " id="station_loop"
                                            onchange="Line_Where(this.value)">
                                        </select>
                                    </div>
                                    <div class="input-group input-group-sm mb-3">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text " style="width: 90px;">Line</label>
                                        </div>
                                        <select class="custom-select " id="line_loop" onchange="(this.value)">
                                        </select>
                                    </div>
                                    <div class="d-flex flex-row ">
                                        <div class="input-group input-group-sm mb-3 ">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroup-sizing-sm"
                                                    style="width: 90px;">Channel
                                                </span>
                                            </div>
                                            <input type="text" class="form-control" aria-label="Sizing example input"
                                                aria-describedby="inputGroup-sizing-sm" id="chname_input">
                                        </div>
                                        <div class="input-group input-group-sm mb-3 ml-3">
                                            <div class="input-group-prepend text-center">
                                                <span class="input-group-text" id="inputGroup-sizing-sm"
                                                    style="width: 90 px;">PLC_REF</span>
                                            </div>
                                            <input type="text" class="form-control" aria-label="Sizing example input"
                                                aria-describedby="inputGroup-sizing-sm" id="plc_input">
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-success  btn-sm" onclick="addItem()">
                                        <i class="fas fa-plus"></i>&nbsp;Add</button>
                                    <button type="button" class="btn btn-primary  btn-sm" onclick="clearTable()">Clear
                                        Table
                                    </button>
                                </form>
                            </div>
                            <div class="col" style="width: 100px; padding-right: 12px;">
                                <!--  <label>Data List</label> -->
                                <table id="dataTable" class="table table-bordered" style="margin:0px; ">
                                    <thead class=" text-center white-text" style=" font-size: 12px;">
                                        <tr>
                                            <th>No</th>
                                            <th>Model</th>
                                            <th>Station</th>
                                            <th>Line</th>
                                            <th>Channel</th>
                                            <th>PLC_REF</th>
                                            <th>Delete</th>

                                        </tr>
                                    </thead>
                                    <tbody class="text-center " style="font-size:14px;">

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="Add_Channel()">Save </button>
                    </div>
                </div>
            </div>
        </div>
        <!------------------------------------ All Modal ------------------------------------------>
        <!-- Modal Add -->
        <!-- <div class="modal fade" id="AddChannelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-plus-circle"></i>&nbsp;Add
                            Channnel
                        </h5>
                    </div>
                    <div class="modal-body p-5">
                        <input id="emp" value="<//?php echo $emp; ?>" hidden />
                        <form id="addchannel">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">

                                    <label class="input-group-text " style="width: 90px;"
                                        for="inputGroupSelect01">Model</label>
                                </div>
                                <select class="custom-select " id="model_loop" onchange="Station_Where(this.value)">
                                </select>
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 90px;">Station</label>
                                </div>
                                <select class="custom-select " id="station_loop" onchange="Line_Where(this.value)">
                                </select>
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 90px;">Line</label>
                                </div>
                                <select class="custom-select " id="line_loop" onchange="(this.value)">
                                </select>
                            </div>
                            <div class="d-flex flex-row ">
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Channel
                                        </span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="chname_input">
                                </div>
                                <div class="input-group input-group-sm mb-3 ml-3">
                                    <div class="input-group-prepend text-center">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90 px;">PLC_REF</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="plc_input">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                            onclick="Clear_Channel()">Cancel</button>
                        <button type="button" class="btn btn-success" onclick="Add_Channel()">Save</button>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- Modal Edit -->
        <input id="channel_id" hidden />
        <div class="modal fade" id="EditChannelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-pen"></i>&nbsp;Edit
                            Channel
                        </h5>
                    </div>
                    <div class="modal-body p-5">
                        <form>
                            <!-- employee_id of user log in -->
                            <input id="emp" value="<?php echo $emp; ?>" hidden />

                            <form>

                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Model</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="model_data" disabled>
                                </div>
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Station</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="station_data" disabled>
                                </div>
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Line</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="line_data" disabled>
                                </div>
                                <!-- <input id="model_data1" hidden /> -->

                                <!-- <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 112px;" for="inputGroupSelect01">New
                                        Model</label>
                                </div>
                                <select class="custom-select " id="model_loop1" onchange="Station_value1(this.value)">
                                </select>
                </div> -->

                                <!--      <label>Station:&nbsp;</label><input type="text" id="station_data1"
                                style="border:none; background:none; " disabled /><input id="station_id" hidden /> -->

                                <!--   <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 112px;" for="inputGroupSelect01">New
                                        Station</label>
                                </div>
                                <select class="custom-select " id="station_loop1" onchange="(this.value)">
                                </select>
                            </div> -->
                                <div class="d-flex flex-row ">
                                    <div class="input-group input-group-sm mb-3 ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroup-sizing-sm"
                                                style="width: 90px;">Channel
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Sizing example input"
                                            aria-describedby="inputGroup-sizing-sm" id="chname_data">
                                    </div>
                                    <div class="input-group input-group-sm mb-3 ml-3">
                                        <div class="input-group-prepend text-center">
                                            <span class="input-group-text" id="inputGroup-sizing-sm"
                                                style="width: 90 px;">PLC_REF</span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Sizing example input"
                                            aria-describedby="inputGroup-sizing-sm" id="plc_data">
                                    </div>
                                </div>
                            </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-success" onclick="Update_Channel()">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <?php require 'component/Footer.php';?>

        <!--------------------------- Script Function And JS File ---------------------------------->

        <!-- Load data func. -->
        <script>
        $(document).ready(function() {
            Load_Channel();
        });
        </script>

        <script>
        function Load_Channel() {
            document.getElementById("show_channel").innerHTML =
                '<div class="center"><span class="loader"></span></div>';

            setTimeout(function() {
                $.ajax({
                    url: "ajax/Channel_Table.php",
                    async: false,
                    cache: false,

                    success: function(result) {
                        document.getElementById("show_channel").innerHTML = result;
                    }
                });
            }, 1000);
        }
        </script>

        <!-- Clear form add func. -->
        <script>
        function Clear_Channel() {
            $("#addchannel").trigger("reset");
            /*   document.getElementById("station_loop").value = "0";
              document.getElementById("model_loop").value = "0";
              document.getElementById("line_loop").value = "0"; */
        }
        </script>

        <script>
        function Line_Where(e) {

            var model = document.getElementById('model_loop').value;

            document.getElementById("station_loop").value = e;
            var station = e;

            $.ajax({
                url: "ajax/Line_Select.php",
                async: false,
                cache: false,
                data: {
                    Model: model,
                    Station: station
                },
                success: function(result) {

                    var myJson = JSON.parse(result);

                    var options =
                        "<select class='form-select' aria-label='Default select example' id='model_new' >";
                    options += "<option value='0' disabled selected>select....</option>";

                    for (let x in myJson) {

                        var id = myJson[x]['Line_ID'];
                        var model_id = myJson[x]['Model_ID'];
                        var name = myJson[x]['Line'];
                        options += "<option value='" + name + "' id = '" + model_id + "'>" + name +
                            "</option>";
                    }
                    options += '</select>';

                    document.getElementById("line_loop").innerHTML = options;

                }
            });
        }
        </script>

        <script>
        function Station_Where(e) {
            document.getElementById("model_loop").value = e;
            var model = e;
            /*     console.log(model);
             */
            $.ajax({
                url: "ajax/Station_Select.php",
                async: false,
                cache: false,
                data: {
                    Model: model
                },
                success: function(result) {

                    var myJson = JSON.parse(result);

                    var options =
                        "<select class='form-select' aria-label='Default select example' id='model_new' >";
                    options += "<option value='0' disabled selected>select....</option>";

                    for (let x in myJson) {

                        var id = myJson[x]['ST_ID'];
                        /* var model_id = myJson[x]['Model_ID']; */
                        var name = myJson[x]['Station'];
                        options += "<option value='" + id + "' id = '" + name + "'>" + name +
                            "</option>";
                    }
                    options += '</select>';

                    document.getElementById("station_loop").innerHTML = options;

                }
            });
        }
        </script>

        <!--------------------------------------------------------------Add List --------------------------------------->
        <script>
        var allDataArray = [];
        </script>

        <script>
        function addItem() {
            var station_id = document.getElementById('station_loop').value;
            var line = document.getElementById('line_loop').value;
            var model_name = document.getElementById('model_loop').value;

            var select = document.getElementById("line_loop");
            var selectedOption = select.options[select.selectedIndex];
            var model_id = selectedOption.id;

            var select1 = document.getElementById("station_loop");
            var selectedOption1 = select1.options[select1.selectedIndex];
            var station_name = selectedOption1.id;
            /*         console.log(select.options[select.selectedIndex].text); */
            var channel = document.getElementById('chname_input').value;
            var plc = document.getElementById('plc_input').value;

            var table = document.getElementById("dataTable");

            // ตรวจสอบว่าข้อมูลมีอยู่ในตารางแล้วหรือไม่
            var isDuplicate = checkDuplicateData(table, model_name, station_name, line, channel, plc);
            if (isDuplicate) {
                alert("ข้อมูลมีอยู่ในตารางแล้ว");
                return;
            }

            var newRow = table.insertRow(table.rows.length);
            var noCell = newRow.insertCell(0);
            var modelCell = newRow.insertCell(1);
            var stationCell = newRow.insertCell(2);
            var lineCell = newRow.insertCell(3);
            var channelCell = newRow.insertCell(4);
            var plcCell = newRow.insertCell(5);
            var actionCell = newRow.insertCell(6);
            var model_ID_Cell = newRow.insertCell(7);
            model_ID_Cell.classList.add('hidden');
            var station_ID_Cell = newRow.insertCell(8);
            station_ID_Cell.classList.add('hidden');

            var rowCount = table.rows.length - 1; // ลบ 1 เพื่อไม่นับแถวหัวตาราง
            noCell.innerHTML = rowCount;
            modelCell.innerHTML = model_name;
            stationCell.innerHTML = station_name;
            lineCell.innerHTML = line;
            channelCell.innerHTML = channel;
            plcCell.innerHTML = plc;
            actionCell.innerHTML = '<i class="fas fa-minus-circle fa-lg delete-icon" onclick="deleteRow(this)"></i>';
            model_ID_Cell.innerHTML = model_id;
            station_ID_Cell.innerHTML = station_id;

            var dataArray = [model_id, station_id, line, channel, plc];
            allDataArray.push(dataArray);
            console.log(allDataArray);

            clearFormInputs();
        }

        function checkDuplicateData(table, model_name, station_name, line, channel, plc) {
            var rows = table.rows;
            for (var i = 1; i < rows.length; i++) { // เริ่มต้นที่ดัชนี 1 เพื่อข้ามแถวหัวตาราง
                var row = rows[i];
                var modelCell = row.cells[1].innerHTML;
                var stationCell = row.cells[2].innerHTML;
                var lineCell = row.cells[3].innerHTML;
                var channelCell = row.cells[4].innerHTML;
                var plcCell = row.cells[5].innerHTML;

                if (
                    modelCell === model_name &&
                    stationCell === station_name &&
                    lineCell === line &&
                    channelCell === channel &&
                    plcCell === plc
                ) {
                    return true;
                }
            }
            return false;
        }

        function deleteRow(button) {
            var row = button.parentNode.parentNode;
            var table = row.parentNode;
            var rowIndex = row.rowIndex;

            table.deleteRow(rowIndex);

            // อัปเดตหมายเลขแถว
            var rows = table.rows;
            for (var i = rowIndex; i < rows.length; i++) {
                var noCell = rows[i].cells[0];
                noCell.innerHTML = i;
            }

            allDataArray.splice(rowIndex - 1, 1);
        }

        function clearTable() {
            var table = document.getElementById("dataTable");
            var rowCount = table.rows.length;

            // เริ่มต้นจากแถวสุดท้ายและลบแต่ละแถว
            for (var i = rowCount - 1; i > 0; i--) {
                table.deleteRow(i);
            }
            allDataArray = [];
        }

        function clearFormInputs() {
            /*  document.getElementById("channel_select").value = "";
             document.getElementById("nijiko_select").value = "";
             document.getElementById("seq").value = "";
             document.getElementById("chname_input").value = "";
             document.getElementById("plc_input").value = ""; */

        }
        </script>

        <!--------------------------------------------------------------Add List --------------------------------------->


        <script src="js/Add_Channel.js"></script>
        <script src="js/Update_Channel.js"></script>
        <script src="js/Del_Channel.js"></script>
        <!--  <script src="js/Select_Station.js"></script> -->
        <script src="js/Select_Model.js"></script>

</body>

</html>