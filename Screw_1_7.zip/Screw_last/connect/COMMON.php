<?php
class suchin_class {

    private $db;   
	function CnndB(){
		$this->db = mssql_connect($this->host, $this->user, $this->password); // Mssql Server
	}

	function CnndBMySQL(){
		$this->db = new mysqli($this->host, $this->user, $this->password, $this->dbname);	// MySql Server
	}

	function GetdBMySql($sql){
		$result = $this->db->query($sql);
		$row='';
		while ($row= $result->fetch_array(MYSQLI_ASSOC)){//MYSQLI_NUM,MYSQLI_ASSOC
			foreach($row as $k=>$v){
				if($v=='' || $v=='0')$v='-';
				if(!empty($v))$temp[$k]=$v;
			}
			$this->result_array[]=$temp;
			if(empty($col)){
				@$this->col_name=array_keys($row);
				$col=1;
			}
		}	
	}

	function GetdB($sql){
		$col=0;
		$this->col_name='';
		
		$r = mssql_query ( $sql,$this->db );


		$row='';
		while ( $row = mssql_fetch_array ( $r,MSSQL_ASSOC) ){
			$this->result_array[]=$row;
			if(empty($col)){
				$this->col_name=array_keys($row);
				$col=1;
			}				
		}	
		
	}
	

	function exec($sql){
		$r = mssql_query( $sql,$this->db );
	}


}


?>