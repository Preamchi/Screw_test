
function Send_ID(e) {
    document.getElementById("process_id").value = e;
    var process_id = e;


    $.ajax({
        type: "GET",
        url: "ajax/Process_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Process_Id : process_id
        },

        success: function(result) {
            const myJson = JSON.parse(result);          
            document.getElementById("station_id").value = myJson.Station_Id; 
            document.getElementById("model_st_data").value = myJson.Station_Detail; 
            document.getElementById("nijiko_name").value = myJson.Nijiko;
           document.getElementById("nijiko_id").value = myJson.Nijiko_Id; 
          /*   document.getElementById("channel_data").value = myJson.Channel;  */
            document.getElementById("channel_data").value = myJson.Channel;
            document.getElementById("sequnce_data").value = myJson.Sequence;
            document.getElementById("sequnce_before_data").value = myJson.Sequence_Before; 
            document.getElementById("torque_data").value = myJson.Torque; 
            document.getElementById("torquemax_data").value = myJson.Torque_Max;
            document.getElementById("torquemin_data").value = myJson.Torque_Min;  
    
        
        
        
          
           
        }
    });

   
}
/*  
function Nijiko_Select1() {
    var n_id = document.getElementById("nijiko_id").value; 
    $.ajax({
        url: "ajax/Nijiko_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='nijiko_select1' >";
            options += "<option value='" + n_id + "' >select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Nijiko'];
                options += "<option value='" + id + "'>" +
                    name + "</option>";
            }
            options += '</select>';

            document.getElementById("nijiko2_select").innerHTML = options;
            
        }
    });
}*/




function Update_Process() {

    var employee = document.getElementById('emp').value;  
    var process_id = document.getElementById('process_id').value;
    var nijiko = document.getElementById('nijiko_data').value;
/*     var seq = document.getElementById('sequnce_data').value; */
    var seq_before = document.getElementById('sequnce_before_data').value; 
    var input2 = parseFloat(document.getElementById("torque_data").value);
    var input1 = parseFloat(document.getElementById("torquemax_data").value);
    var input3 = parseFloat(document.getElementById("torquemin_data").value);
/* 

    console.log(employee,pro_id,nijiko,seq,seq_before,input1,input2,input3); */

    if ((!seq ) || (!seq_before) || isNaN(input1) || isNaN(input2) || isNaN(input3) ) {

        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });

    } else if (!(input1 >= input2 && input2 >= input3)){
        Swal.fire({
            width: 400,
            title: 'Please enter values : max > medium > min.!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
       
    }else{
        $.ajax({
            type: "GET",
            url: "ajax/Process_Update.php",
            async: false,
            cache: false,
            data: {
                Employee : employee,
                Process_Id : process_id,
                Nijiko : nijiko,
            /*     Seq : seq, */
                Seq_Before : seq_before,
                Torque_Max : input1,  
                Torque : input2, 
                Torque_Min :input3
               
            },
            success: function(result) {
                  Swal.fire({
                    width: 400,
                    title: 'Update Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });

                  $('#editprocessModal').modal('hide');
                  $('.modal-backdrop').remove();
                  Load_Process(); 
     }
        });
    }

}   