function Search_User() {
    var id_search = document.getElementById('input').value;
   
    if ((!id_search)) {
      Swal.fire({
          width: 400,
          title: 'Please input GID OR ID!',
          icon: 'warning',
          showConfirmButton: false,
          timer: 1500
        });
  } else {
    $.ajax({
        type: "GET",
        url: "ajax/User_Search.php",
        async: false,
        cache: false,
        data: {
            search: id_search
        },

        success: function(result) {
       
          if (result == 'no') {
            Swal.fire({
                width: 400,
                title: 'User not found',
                icon: 'error',
                showConfirmButton: false,
                timer: 1500
              });
              document.getElementById("emp_name").value = '';
          } else {
              const myJson = JSON.parse(result);
            document.getElementById("emp_name").value = myJson.EMP_NAME_EN;
            document.getElementById("emp_gid").value = myJson.EMP_GID;
          }
        }
    });
  }
}