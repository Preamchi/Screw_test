function Add_Screw() {
   
    var emp = document.getElementById('emp').value;
    var part_no = document.getElementById('partno_input').value;
    var screw_name = document.getElementById('screwname_input').value;   

    if ((!part_no) || (!screw_name) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Screw_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp,
                Part_no: part_no,
                Screw_name: screw_name,
            
            },
            success: function(result) {
                if(result == 'have_data'){
                    Swal.fire({
                        width: 400,
                        title: 'Add failed!',
                        text: 'User information already exists.',
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1500
                      });
                      document.getElementById("screwname_input").value = '';
                      document.getElementById("partno_input").value = '';
                      
                }else{
                     Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1700
                  });

                $('#AddScrewModal').modal('hide');
                $('.modal-backdrop').remove(); 
                $("#addscrew").trigger("reset");
                Load_Screw(); 
                }
               
     }
        });
    }
}
