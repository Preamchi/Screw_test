<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Machine_ID = $_GET[Machine_ID];

$sql=" DELETE [STT_DB].[IM].[SCREW_TQ_Nijiko] WHERE ID = '$Machine_ID'";
$myfunction->exec($sql);
die;
?>