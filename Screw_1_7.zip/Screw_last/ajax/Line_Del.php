<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();



$Line_ID = $_GET[Line_id];

$sql=" 
DELETE FROM [STT_DB].[IM].[SCREW_TQ_Line] WHERE ID = '$Line_ID'";
$myfunction->exec($sql);
die;
?>