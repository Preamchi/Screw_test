<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Admin_ID = $_GET[Admin_ID];
$Emp_ID = $_GET[Emp_ID];
$New_Role = $_GET[New_Role];

 $sql =" 
 UPDATE [STT_DB].[IM].[SCREW_TQ_User]
 SET [Emp_Role] = '".$New_Role."'
    ,[Update_By] = '".$Admin_ID."'
    ,[Create_Date] = GETDATE()
    ,[Update_Date] = GETDATE()
WHERE Emp_ID = '".$Emp_ID."'";
$myfunction->exec($sql); 

?>