<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$dataArray = $_POST['dataArray'];
$emp = $_POST['emp'];
echo '<pre>'print_r($dataArray,$emp )'</pre>';

foreach ($dataArray as $row) {
  $model_id = $row[0];
  $station_id = $row[1];
  $line = $row[2];
  $channel = $row[3];
  $plc = $row[4];

  // ใช้ prepared statements เพื่อป้องกันการโจมตี SQL injection
  $sql_check = "
  SELECT * FROM [STT_DB].[IM].[SCREW_TQ_Channel] WHERE Channel = ? AND Model_Id = ? AND Station_Id = ?";
  
  // ผูกค่าพารามิเตอร์
  $params = array($channel, $model_id, $station_id);
  
  $getdata = '';
  $myfunction->result_array = '';
  
  // ประมวลผลคำสั่ง SQL
  $myfunction->getdb($sql_check, 'mssql', $params);
  $getdata = $myfunction->result_array;

  if ($getdata == '') {
    $sql="
    INSERT INTO [STT_DB].[IM].[SCREW_TQ_Channel]
               ([Channel]
               ,[PLC_Ref]
               ,[Model_Id]
               ,[Station_Id]
               ,[Create_Date]
               ,[Create_By]
               ,[Update_Date]
               ,[Update_By])
    VALUES(?, ?, ?, ?, GETDATE(), ?, GETDATE(), ?)"; 

    // ผูกค่าพารามิเตอร์สำหรับคำสั่ง INSERT
    $params = array($channel, $plc, $model_id, $station_id, $emp, $emp);

    $myfunction->exec($sql, 'mssql', $params);
  } else {
    echo 'have_data';
  } 
}
?>