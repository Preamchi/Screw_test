<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = " 
SELECT Distinct [Model] AS Model FROM [STT_DB].[IM].[SCREW_TQ_Model] ";
/*  */ 
$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata);

/* 
$Model1 = $_GET[Model];
$sql1 = "
SELECT Distinct B.[Station] AS Station,
A.[ID] AS ID
FROM [STT_DB].[IM].[SCREW_TQ_Model] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] B 
ON A.[Station_Id] = B.ID WHERE A.Model = '$Model1'";

$getdata1 = '';
$myfunction->result_array = '';
$myfunction->getdb($sql1 ,'mssql');
$getdata1 = $myfunction->result_array;

 echo json_encode($getdata1)  */

/* 
 foreach($getdata as $x => $val) {
    $data_cart[$val[ID]] = $val;
}


 $data_cart1 = json_encode($data_cart);
   print_r ($data_cart1); 
    
 */
?>