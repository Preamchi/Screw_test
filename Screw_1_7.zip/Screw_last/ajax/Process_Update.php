<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();




$Employee = $_GET[Employee];
$Process_ID = $_GET[Process_Id];
$Nijiko = $_GET[Nijiko];
/* $Seq = $_GET[Seq]; */
$Seq_Before = $_GET[Seq_Before];
$Torq = $_GET[Torque];
$Torq_Max = $_GET[Torque_Max];
$Torq_Min = $_GET[Torque_Min];


$sql="
UPDATE [STT_DB].[IM].[SCREW_TQ_Sequence]
SET 
   [Sequence_Before] = '".$Seq_Before."'
   ,[Torque] = '".$Torq."'
   ,[Torque_Max] = '".$Torq_Max."'
   ,[Torque_Min] = '".$Torq_Min ."'
   ,[Nijiko_Id] = '".$Nijiko."'
   ,[Update_Date] = GETDATE()
   ,[Update_By] = '".$Employee."'
WHERE ID = '".$Process_ID ."'";

    $myfunction->exec($sql); 
    echo($sql);


?>