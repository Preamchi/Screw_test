<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Channel_ID= $_GET[Channel_ID];
/*    ,A.[Station_Id] AS ST_ID
    ,B.[ID] AS Model_ID */

$sql = " 
SELECT 
    A.[ID]
    ,[Channel]
    ,B.[Model] AS Model
    ,[PLC_REF],
    C.[Station] AS Station
    ,D.[Line] As Line
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B
ON A.Model_Id = B.ID
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] C
ON B.Station_Id = C.ID 
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Line] D
ON B.Line_Id = D.ID
 WHERE A.ID = '$Channel_ID';
";

/* SELECT [CH_ID]
,[Channel_Name]
,[Cart_Name]
,[Part_No]
 FROM [STT_DB].[IM].[TBL_ScrewDV_Pm_Channel] WHERE CH_ID = '$Channel_ID'
 */
 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_channel = $val;
}

$data_channel1 = json_encode($data_channel);
    echo $data_channel1;

    
 
?>