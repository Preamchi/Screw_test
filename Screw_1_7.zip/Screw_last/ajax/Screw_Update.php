<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Employee = $_GET[Emp];
$Screw_ID = $_GET[Screw_ID];
$Part_No = $_GET[Part_No];
$Screw_Name = $_GET[Screw_Name];

$sql_check = "
SELECT [Screw_Name] FROM [STT_DB].[IM].[SCREW_TQ_ScrewType] WHERE Screw_Name = '$Screw_Name' OR Part_No = '$Part_No' "; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){
    
    $sql =" UPDATE [STT_DB].[IM].[SCREW_TQ_ScrewType] SET Part_No = '".$Part_No."',Screw_Name = '".$Screw_Name."',Update_By = '".$Employee."',Update_Date = GETDATE()
    WHERE ID = '".$Screw_ID."'";
    $myfunction->exec($sql); 
 echo $sql;
     
    }else{
        echo 'have_data';
    }
    
    



?>