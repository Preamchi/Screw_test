<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = "
SELECT [Station], [ID] FROM [STT_DB].[IM].[SCREW_TQ_Station] ORDER BY LEN(Station) ASC";


$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata)

?>