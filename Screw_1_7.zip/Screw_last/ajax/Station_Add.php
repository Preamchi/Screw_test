<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$ST_Name = $_GET[ST_Name];

$sql_check = " SELECT [Station] FROM [STT_DB].[IM].[SCREW_TQ_Station] WHERE Station = '$ST_Name'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){
    
   $sql="
   INSERT INTO [STT_DB].[IM].[SCREW_TQ_Station]
              ([Station]
              ,[Create_Date]
              ,[Create_By]
              ,[Update_Date]
              ,[Update_By])
       VALUES('".$ST_Name."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 
   
    $myfunction->exec($sql);
    echo $sql;
        
       }else{
           echo 'have_data';
       }
       
   



?>